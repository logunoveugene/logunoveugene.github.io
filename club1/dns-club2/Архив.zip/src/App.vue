<template>
    <div id="app">
        <mainheader :live="live" :isAuth="isAuth" v-on:liveon="liveon" v-on:auth="auth" v-on:logout="logout"></mainheader>
        <efir-bar :live="live" v-on:liveoff="liveoff"></efir-bar>
        <div class="main-layout" :class="live">
            <transition name="сfade">

                <router-view :isAuth="isAuth" />

            </transition>
            <myfooter></myfooter>
        </div>
    </div>
</template>

<script>
    import mainheader from "./components/header.vue"
    import myfooter from "./components/footer.vue"
    import efir from "./components/efir.vue"

    export default {
        components: {
            mainheader,
            myfooter,
            'efir-bar': efir

        },
        data: function () {
            return {

                live: "showlive",
                isAuth: true,
                window: {
                    width: 0,
                    height: 0
                }

            }
        },
        methods: {

            liveoff: function () {
                this.live = "";
            },
            liveon: function () {
                this.live = "showlive";
            },
            auth: function () {
                this.isAuth = true;
            },
            logout: function () {
                this.isAuth = false;
            },
            handleResize() {
                this.window.width = window.innerWidth;
                this.window.height = window.innerHeight;
                if (this.window.width < 1440) {
                    this.live = "";
                }
            }

        },

        created() {
            window.addEventListener('resize', this.handleResize)
            this.handleResize();
        },

        destroyed() {
            window.removeEventListener('resize', this.handleResize)
        }
    }


</script>

<style lang="scss">
    .сfade-enter-active, .сfade-leave-active {
        transition-property: opacity;
        transition-duration: .35s;
    }

    .сfade-enter-active {
        transition-delay: .35s;
    }

    .сfade-enter, .сfade-leave-active {
        opacity: 0;


    }

    .tooltip {
        display: block !important;
        z-index: 10000;

        .tooltip-inner {
            background: black;
            color: white;
            border-radius: 16px;
            padding: 0;
        }

        .tooltip-arrow {
            width: 0;
            height: 0;
            border-style: solid;
            position: absolute;
            margin: 5px;
            border-color: black;
            z-index: 1;
        }

        &[x-placement^="top"] {
            margin-bottom: 5px;

            .tooltip-arrow {
                border-width: 5px 5px 0 5px;
                border-left-color: transparent !important;
                border-right-color: transparent !important;
                border-bottom-color: transparent !important;
                bottom: -5px;
                left: calc(50% - 5px);
                margin-top: 0;
                margin-bottom: 0;
            }
        }

        &[x-placement^="bottom"] {
            margin-top: 5px;

            .tooltip-arrow {
                border-width: 0 5px 5px 5px;
                border-left-color: transparent !important;
                border-right-color: transparent !important;
                border-top-color: transparent !important;
                top: -5px;
                left: calc(50% - 5px);
                margin-top: 0;
                margin-bottom: 0;
            }
        }

        &[x-placement^="right"] {
            margin-left: 5px;

            .tooltip-arrow {
                border-width: 5px 5px 5px 0;
                border-left-color: transparent !important;
                border-top-color: transparent !important;
                border-bottom-color: transparent !important;
                left: -5px;
                top: calc(50% - 5px);
                margin-left: 0;
                margin-right: 0;
            }
        }

        &[x-placement^="left"] {
            margin-right: 5px;

            .tooltip-arrow {
                border-width: 5px 0 5px 5px;
                border-top-color: transparent !important;
                border-right-color: transparent !important;
                border-bottom-color: transparent !important;
                right: -5px;
                top: calc(50% - 5px);
                margin-left: 0;
                margin-right: 0;
            }
        }

        &.popover {
            $color: #f9f9f9;
            border: none;

            .popover-inner {
                background: #fff;
                color: black;
                border-radius: 5px;
                box-shadow: 0 5px 30px rgba(black, .1);
            }

            .popover-arrow {
                border-color: $color;
            }
        }

        &[aria-hidden='true'] {
            visibility: hidden;
            opacity: 0;
            transition: opacity .15s, visibility .15s;
        }

        &[aria-hidden='false'] {
            visibility: visible;
            opacity: 1;
            transition: opacity .15s;
        }
    }
</style>
